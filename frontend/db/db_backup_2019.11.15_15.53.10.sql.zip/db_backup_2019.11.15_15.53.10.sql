-- -------------------------------------------
SET AUTOCOMMIT=0;
START TRANSACTION;
SET SQL_QUOTE_SHOW_CREATE = 1;
SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
-- -------------------------------------------
-- -------------------------------------------
-- START BACKUP
-- -------------------------------------------
-- -------------------------------------------
-- TABLE `auth_assignment`
-- -------------------------------------------
DROP TABLE IF EXISTS `auth_assignment`;
CREATE TABLE IF NOT EXISTS `auth_assignment` (
  `item_name` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `user_id` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` int(11) DEFAULT NULL,
  PRIMARY KEY (`item_name`,`user_id`),
  KEY `auth_assignment_user_id_idx` (`user_id`),
  CONSTRAINT `auth_assignment_ibfk_1` FOREIGN KEY (`item_name`) REFERENCES `auth_item` (`name`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- -------------------------------------------
-- TABLE `auth_item`
-- -------------------------------------------
DROP TABLE IF EXISTS `auth_item`;
CREATE TABLE IF NOT EXISTS `auth_item` (
  `name` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `type` smallint(6) NOT NULL,
  `description` text COLLATE utf8_unicode_ci,
  `rule_name` varchar(64) COLLATE utf8_unicode_ci DEFAULT NULL,
  `data` blob,
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL,
  PRIMARY KEY (`name`),
  KEY `rule_name` (`rule_name`),
  KEY `idx-auth_item-type` (`type`),
  CONSTRAINT `auth_item_ibfk_1` FOREIGN KEY (`rule_name`) REFERENCES `auth_rule` (`name`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- -------------------------------------------
-- TABLE `auth_item_child`
-- -------------------------------------------
DROP TABLE IF EXISTS `auth_item_child`;
CREATE TABLE IF NOT EXISTS `auth_item_child` (
  `parent` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `child` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`parent`,`child`),
  KEY `child` (`child`),
  CONSTRAINT `auth_item_child_ibfk_1` FOREIGN KEY (`parent`) REFERENCES `auth_item` (`name`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `auth_item_child_ibfk_2` FOREIGN KEY (`child`) REFERENCES `auth_item` (`name`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- -------------------------------------------
-- TABLE `auth_rule`
-- -------------------------------------------
DROP TABLE IF EXISTS `auth_rule`;
CREATE TABLE IF NOT EXISTS `auth_rule` (
  `name` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `data` blob,
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL,
  PRIMARY KEY (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- -------------------------------------------
-- TABLE `book`
-- -------------------------------------------
DROP TABLE IF EXISTS `book`;
CREATE TABLE IF NOT EXISTS `book` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `category_id` int(11) NOT NULL,
  `code1` varchar(50) NOT NULL,
  `code2` varchar(50) NOT NULL,
  `name` text NOT NULL,
  `author` varchar(100) NOT NULL,
  `lib_ref_no` varchar(50) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `ori_stock` int(11) NOT NULL DEFAULT '0',
  `cur_stock` int(11) NOT NULL DEFAULT '0',
  `shelf_no` varchar(50) NOT NULL,
  `publish_type` varchar(50) NOT NULL,
  `status` enum('Active','Inactive') NOT NULL,
  `created_date` datetime NOT NULL,
  `created_by` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `book_r_category` (`category_id`),
  CONSTRAINT `book_r_category` FOREIGN KEY (`category_id`) REFERENCES `category` (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1;

-- -------------------------------------------
-- TABLE `category`
-- -------------------------------------------
DROP TABLE IF EXISTS `category`;
CREATE TABLE IF NOT EXISTS `category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `status` enum('Active','Inactive') NOT NULL,
  `created_date` datetime NOT NULL,
  `created_by` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1;

-- -------------------------------------------
-- TABLE `class`
-- -------------------------------------------
DROP TABLE IF EXISTS `class`;
CREATE TABLE IF NOT EXISTS `class` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `status` enum('Active','Inactive') NOT NULL,
  `created_date` datetime NOT NULL,
  `created_by` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1;

-- -------------------------------------------
-- TABLE `fine`
-- -------------------------------------------
DROP TABLE IF EXISTS `fine`;
CREATE TABLE IF NOT EXISTS `fine` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `class_id` int(11) NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `min_days` int(11) NOT NULL DEFAULT '0',
  `max_days` int(11) NOT NULL DEFAULT '0',
  `status` enum('Active','Inactive') NOT NULL,
  `created_date` datetime NOT NULL,
  `created_by` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fine_r_class` (`class_id`),
  CONSTRAINT `fine_r_class` FOREIGN KEY (`class_id`) REFERENCES `class` (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1;

-- -------------------------------------------
-- TABLE `issue`
-- -------------------------------------------
DROP TABLE IF EXISTS `issue`;
CREATE TABLE IF NOT EXISTS `issue` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `book_id` int(11) NOT NULL,
  `member_id` int(11) NOT NULL,
  `status_id` int(11) NOT NULL,
  `created_date` datetime NOT NULL,
  `created_by` int(11) NOT NULL,
  `fine` decimal(10,2) NOT NULL DEFAULT '0.00',
  `remark` text NOT NULL,
  `s_date` date NOT NULL,
  `e_date` date NOT NULL,
  PRIMARY KEY (`id`),
  KEY `status_id` (`status_id`),
  CONSTRAINT `issue_ibfk_1` FOREIGN KEY (`status_id`) REFERENCES `status` (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1;

-- -------------------------------------------
-- TABLE `issue_status`
-- -------------------------------------------
DROP TABLE IF EXISTS `issue_status`;
CREATE TABLE IF NOT EXISTS `issue_status` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `issue_id` int(11) NOT NULL,
  `status_id` int(11) NOT NULL,
  `remark` text,
  `created_by` int(11) NOT NULL,
  `created_date` date NOT NULL,
  PRIMARY KEY (`id`),
  KEY `issue_id` (`issue_id`),
  KEY `status_id` (`status_id`),
  CONSTRAINT `issue_status_ibfk_1` FOREIGN KEY (`issue_id`) REFERENCES `issue` (`id`),
  CONSTRAINT `issue_status_ibfk_2` FOREIGN KEY (`status_id`) REFERENCES `status` (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1;

-- -------------------------------------------
-- TABLE `member`
-- -------------------------------------------
DROP TABLE IF EXISTS `member`;
CREATE TABLE IF NOT EXISTS `member` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `class_id` int(11) NOT NULL,
  `code` varchar(20) NOT NULL,
  `name` varchar(50) NOT NULL,
  `address` text NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone` bigint(20) NOT NULL,
  `status` enum('Active','Inactive') NOT NULL,
  `created_date` datetime NOT NULL,
  `created_by` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `member_r_class` (`class_id`),
  CONSTRAINT `member_r_class` FOREIGN KEY (`class_id`) REFERENCES `class` (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1;

-- -------------------------------------------
-- TABLE `migration`
-- -------------------------------------------
DROP TABLE IF EXISTS `migration`;
CREATE TABLE IF NOT EXISTS `migration` (
  `version` varchar(180) NOT NULL,
  `apply_time` int(11) DEFAULT NULL,
  PRIMARY KEY (`version`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- -------------------------------------------
-- TABLE `organisation`
-- -------------------------------------------
DROP TABLE IF EXISTS `organisation`;
CREATE TABLE IF NOT EXISTS `organisation` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `address` text NOT NULL,
  `pin` int(11) NOT NULL,
  `phone` bigint(20) NOT NULL,
  `email` varchar(255) NOT NULL,
  `logo` varchar(255) DEFAULT NULL,
  `created_date` datetime NOT NULL,
  `created_by` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1;

-- -------------------------------------------
-- TABLE `purchase_receipt`
-- -------------------------------------------
DROP TABLE IF EXISTS `purchase_receipt`;
CREATE TABLE IF NOT EXISTS `purchase_receipt` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `book_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `total_price` decimal(10,2) NOT NULL,
  `purchase_order_no` varchar(50) DEFAULT NULL,
  `supplier` varchar(100) DEFAULT NULL,
  `created_by` int(11) NOT NULL,
  `created_date` date NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1;

-- -------------------------------------------
-- TABLE `status`
-- -------------------------------------------
DROP TABLE IF EXISTS `status`;
CREATE TABLE IF NOT EXISTS `status` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `status` enum('Active','Inactive') NOT NULL,
  `created_date` date NOT NULL,
  `created_by` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1;

-- -------------------------------------------
-- TABLE `subcategory`
-- -------------------------------------------
DROP TABLE IF EXISTS `subcategory`;
CREATE TABLE IF NOT EXISTS `subcategory` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `category_id` int(11) NOT NULL,
  `status` enum('Active','Inactive') NOT NULL,
  `created_date` datetime NOT NULL,
  `created_by` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `category_id` (`category_id`),
  CONSTRAINT `subcategory_ibfk_1` FOREIGN KEY (`category_id`) REFERENCES `category` (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1;

-- -------------------------------------------
-- TABLE `user`
-- -------------------------------------------
DROP TABLE IF EXISTS `user`;
CREATE TABLE IF NOT EXISTS `user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `auth_key` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `password_hash` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `password_reset_token` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `status` smallint(6) NOT NULL DEFAULT '10',
  `created_at` int(11) NOT NULL,
  `updated_at` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `email` (`email`),
  UNIQUE KEY `password_reset_token` (`password_reset_token`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- -------------------------------------------
-- TABLE DATA auth_assignment
-- -------------------------------------------
INSERT INTO `auth_assignment` (`item_name`,`user_id`,`created_at`) VALUES
('Admin','1','1569648913');;;
INSERT INTO `auth_assignment` (`item_name`,`user_id`,`created_at`) VALUES
('librarian','2','1571475341');;;
INSERT INTO `auth_assignment` (`item_name`,`user_id`,`created_at`) VALUES
('librarian','3','1571309611');;;
-- -------------------------------------------
-- TABLE DATA auth_item
-- -------------------------------------------
INSERT INTO `auth_item` (`name`,`type`,`description`,`rule_name`,`data`,`created_at`,`updated_at`) VALUES
('/*','2','','','','1569648900','1569648900');;;
INSERT INTO `auth_item` (`name`,`type`,`description`,`rule_name`,`data`,`created_at`,`updated_at`) VALUES
('/admin/*','2','','','','1571309541','1571309541');;;
INSERT INTO `auth_item` (`name`,`type`,`description`,`rule_name`,`data`,`created_at`,`updated_at`) VALUES
('/admin/assignment/*','2','','','','1571309539','1571309539');;;
INSERT INTO `auth_item` (`name`,`type`,`description`,`rule_name`,`data`,`created_at`,`updated_at`) VALUES
('/admin/assignment/assign','2','','','','1571309539','1571309539');;;
INSERT INTO `auth_item` (`name`,`type`,`description`,`rule_name`,`data`,`created_at`,`updated_at`) VALUES
('/admin/assignment/index','2','','','','1571309539','1571309539');;;
INSERT INTO `auth_item` (`name`,`type`,`description`,`rule_name`,`data`,`created_at`,`updated_at`) VALUES
('/admin/assignment/revoke','2','','','','1571309539','1571309539');;;
INSERT INTO `auth_item` (`name`,`type`,`description`,`rule_name`,`data`,`created_at`,`updated_at`) VALUES
('/admin/assignment/view','2','','','','1571309539','1571309539');;;
INSERT INTO `auth_item` (`name`,`type`,`description`,`rule_name`,`data`,`created_at`,`updated_at`) VALUES
('/admin/default/*','2','','','','1571309539','1571309539');;;
INSERT INTO `auth_item` (`name`,`type`,`description`,`rule_name`,`data`,`created_at`,`updated_at`) VALUES
('/admin/default/index','2','','','','1571309539','1571309539');;;
INSERT INTO `auth_item` (`name`,`type`,`description`,`rule_name`,`data`,`created_at`,`updated_at`) VALUES
('/admin/menu/*','2','','','','1571309540','1571309540');;;
INSERT INTO `auth_item` (`name`,`type`,`description`,`rule_name`,`data`,`created_at`,`updated_at`) VALUES
('/admin/menu/create','2','','','','1571309540','1571309540');;;
INSERT INTO `auth_item` (`name`,`type`,`description`,`rule_name`,`data`,`created_at`,`updated_at`) VALUES
('/admin/menu/delete','2','','','','1571309540','1571309540');;;
INSERT INTO `auth_item` (`name`,`type`,`description`,`rule_name`,`data`,`created_at`,`updated_at`) VALUES
('/admin/menu/index','2','','','','1571309539','1571309539');;;
INSERT INTO `auth_item` (`name`,`type`,`description`,`rule_name`,`data`,`created_at`,`updated_at`) VALUES
('/admin/menu/update','2','','','','1571309540','1571309540');;;
INSERT INTO `auth_item` (`name`,`type`,`description`,`rule_name`,`data`,`created_at`,`updated_at`) VALUES
('/admin/menu/view','2','','','','1571309540','1571309540');;;
INSERT INTO `auth_item` (`name`,`type`,`description`,`rule_name`,`data`,`created_at`,`updated_at`) VALUES
('/admin/permission/*','2','','','','1571309540','1571309540');;;
INSERT INTO `auth_item` (`name`,`type`,`description`,`rule_name`,`data`,`created_at`,`updated_at`) VALUES
('/admin/permission/assign','2','','','','1571309540','1571309540');;;
INSERT INTO `auth_item` (`name`,`type`,`description`,`rule_name`,`data`,`created_at`,`updated_at`) VALUES
('/admin/permission/create','2','','','','1571309540','1571309540');;;
INSERT INTO `auth_item` (`name`,`type`,`description`,`rule_name`,`data`,`created_at`,`updated_at`) VALUES
('/admin/permission/delete','2','','','','1571309540','1571309540');;;
INSERT INTO `auth_item` (`name`,`type`,`description`,`rule_name`,`data`,`created_at`,`updated_at`) VALUES
('/admin/permission/index','2','','','','1571309540','1571309540');;;
INSERT INTO `auth_item` (`name`,`type`,`description`,`rule_name`,`data`,`created_at`,`updated_at`) VALUES
('/admin/permission/remove','2','','','','1571309540','1571309540');;;
INSERT INTO `auth_item` (`name`,`type`,`description`,`rule_name`,`data`,`created_at`,`updated_at`) VALUES
('/admin/permission/update','2','','','','1571309540','1571309540');;;
INSERT INTO `auth_item` (`name`,`type`,`description`,`rule_name`,`data`,`created_at`,`updated_at`) VALUES
('/admin/permission/view','2','','','','1571309540','1571309540');;;
INSERT INTO `auth_item` (`name`,`type`,`description`,`rule_name`,`data`,`created_at`,`updated_at`) VALUES
('/admin/role/*','2','','','','1571309541','1571309541');;;
INSERT INTO `auth_item` (`name`,`type`,`description`,`rule_name`,`data`,`created_at`,`updated_at`) VALUES
('/admin/role/assign','2','','','','1571309540','1571309540');;;
INSERT INTO `auth_item` (`name`,`type`,`description`,`rule_name`,`data`,`created_at`,`updated_at`) VALUES
('/admin/role/create','2','','','','1571309540','1571309540');;;
INSERT INTO `auth_item` (`name`,`type`,`description`,`rule_name`,`data`,`created_at`,`updated_at`) VALUES
('/admin/role/delete','2','','','','1571309540','1571309540');;;
INSERT INTO `auth_item` (`name`,`type`,`description`,`rule_name`,`data`,`created_at`,`updated_at`) VALUES
('/admin/role/index','2','','','','1571309540','1571309540');;;
INSERT INTO `auth_item` (`name`,`type`,`description`,`rule_name`,`data`,`created_at`,`updated_at`) VALUES
('/admin/role/remove','2','','','','1571309541','1571309541');;;
INSERT INTO `auth_item` (`name`,`type`,`description`,`rule_name`,`data`,`created_at`,`updated_at`) VALUES
('/admin/role/update','2','','','','1571309540','1571309540');;;
INSERT INTO `auth_item` (`name`,`type`,`description`,`rule_name`,`data`,`created_at`,`updated_at`) VALUES
('/admin/role/view','2','','','','1571309540','1571309540');;;
INSERT INTO `auth_item` (`name`,`type`,`description`,`rule_name`,`data`,`created_at`,`updated_at`) VALUES
('/admin/route/*','2','','','','1571309541','1571309541');;;
INSERT INTO `auth_item` (`name`,`type`,`description`,`rule_name`,`data`,`created_at`,`updated_at`) VALUES
('/admin/route/assign','2','','','','1571309541','1571309541');;;
INSERT INTO `auth_item` (`name`,`type`,`description`,`rule_name`,`data`,`created_at`,`updated_at`) VALUES
('/admin/route/create','2','','','','1571309541','1571309541');;;
INSERT INTO `auth_item` (`name`,`type`,`description`,`rule_name`,`data`,`created_at`,`updated_at`) VALUES
('/admin/route/index','2','','','','1571309541','1571309541');;;
INSERT INTO `auth_item` (`name`,`type`,`description`,`rule_name`,`data`,`created_at`,`updated_at`) VALUES
('/admin/route/refresh','2','','','','1571309541','1571309541');;;
INSERT INTO `auth_item` (`name`,`type`,`description`,`rule_name`,`data`,`created_at`,`updated_at`) VALUES
('/admin/route/remove','2','','','','1571309541','1571309541');;;
INSERT INTO `auth_item` (`name`,`type`,`description`,`rule_name`,`data`,`created_at`,`updated_at`) VALUES
('/admin/rule/*','2','','','','1571309541','1571309541');;;
INSERT INTO `auth_item` (`name`,`type`,`description`,`rule_name`,`data`,`created_at`,`updated_at`) VALUES
('/admin/rule/create','2','','','','1571309541','1571309541');;;
INSERT INTO `auth_item` (`name`,`type`,`description`,`rule_name`,`data`,`created_at`,`updated_at`) VALUES
('/admin/rule/delete','2','','','','1571309541','1571309541');;;
INSERT INTO `auth_item` (`name`,`type`,`description`,`rule_name`,`data`,`created_at`,`updated_at`) VALUES
('/admin/rule/index','2','','','','1571309541','1571309541');;;
INSERT INTO `auth_item` (`name`,`type`,`description`,`rule_name`,`data`,`created_at`,`updated_at`) VALUES
('/admin/rule/update','2','','','','1571309541','1571309541');;;
INSERT INTO `auth_item` (`name`,`type`,`description`,`rule_name`,`data`,`created_at`,`updated_at`) VALUES
('/admin/rule/view','2','','','','1571309541','1571309541');;;
INSERT INTO `auth_item` (`name`,`type`,`description`,`rule_name`,`data`,`created_at`,`updated_at`) VALUES
('/admin/user/*','2','','','','1571309541','1571309541');;;
INSERT INTO `auth_item` (`name`,`type`,`description`,`rule_name`,`data`,`created_at`,`updated_at`) VALUES
('/admin/user/activate','2','','','','1571309541','1571309541');;;
INSERT INTO `auth_item` (`name`,`type`,`description`,`rule_name`,`data`,`created_at`,`updated_at`) VALUES
('/admin/user/change-password','2','','','','1571309541','1571309541');;;
INSERT INTO `auth_item` (`name`,`type`,`description`,`rule_name`,`data`,`created_at`,`updated_at`) VALUES
('/admin/user/delete','2','','','','1571309541','1571309541');;;
INSERT INTO `auth_item` (`name`,`type`,`description`,`rule_name`,`data`,`created_at`,`updated_at`) VALUES
('/admin/user/index','2','','','','1571309541','1571309541');;;
INSERT INTO `auth_item` (`name`,`type`,`description`,`rule_name`,`data`,`created_at`,`updated_at`) VALUES
('/admin/user/login','2','','','','1571309541','1571309541');;;
INSERT INTO `auth_item` (`name`,`type`,`description`,`rule_name`,`data`,`created_at`,`updated_at`) VALUES
('/admin/user/logout','2','','','','1571309541','1571309541');;;
INSERT INTO `auth_item` (`name`,`type`,`description`,`rule_name`,`data`,`created_at`,`updated_at`) VALUES
('/admin/user/request-password-reset','2','','','','1571309541','1571309541');;;
INSERT INTO `auth_item` (`name`,`type`,`description`,`rule_name`,`data`,`created_at`,`updated_at`) VALUES
('/admin/user/reset-password','2','','','','1571309541','1571309541');;;
INSERT INTO `auth_item` (`name`,`type`,`description`,`rule_name`,`data`,`created_at`,`updated_at`) VALUES
('/admin/user/signup','2','','','','1571309541','1571309541');;;
INSERT INTO `auth_item` (`name`,`type`,`description`,`rule_name`,`data`,`created_at`,`updated_at`) VALUES
('/admin/user/view','2','','','','1571309541','1571309541');;;
INSERT INTO `auth_item` (`name`,`type`,`description`,`rule_name`,`data`,`created_at`,`updated_at`) VALUES
('/backup/*','2','','','','1571309542','1571309542');;;
INSERT INTO `auth_item` (`name`,`type`,`description`,`rule_name`,`data`,`created_at`,`updated_at`) VALUES
('/backup/default/*','2','','','','1571309542','1571309542');;;
INSERT INTO `auth_item` (`name`,`type`,`description`,`rule_name`,`data`,`created_at`,`updated_at`) VALUES
('/backup/default/clean','2','','','','1571309542','1571309542');;;
INSERT INTO `auth_item` (`name`,`type`,`description`,`rule_name`,`data`,`created_at`,`updated_at`) VALUES
('/backup/default/create','2','','','','1571309542','1571309542');;;
INSERT INTO `auth_item` (`name`,`type`,`description`,`rule_name`,`data`,`created_at`,`updated_at`) VALUES
('/backup/default/delete','2','','','','1571309542','1571309542');;;
INSERT INTO `auth_item` (`name`,`type`,`description`,`rule_name`,`data`,`created_at`,`updated_at`) VALUES
('/backup/default/download','2','','','','1571309542','1571309542');;;
INSERT INTO `auth_item` (`name`,`type`,`description`,`rule_name`,`data`,`created_at`,`updated_at`) VALUES
('/backup/default/downloaddb','2','','','','1571309542','1571309542');;;
INSERT INTO `auth_item` (`name`,`type`,`description`,`rule_name`,`data`,`created_at`,`updated_at`) VALUES
('/backup/default/index','2','','','','1571309542','1571309542');;;
INSERT INTO `auth_item` (`name`,`type`,`description`,`rule_name`,`data`,`created_at`,`updated_at`) VALUES
('/backup/default/restore','2','','','','1571309542','1571309542');;;
INSERT INTO `auth_item` (`name`,`type`,`description`,`rule_name`,`data`,`created_at`,`updated_at`) VALUES
('/backup/default/upload','2','','','','1571309542','1571309542');;;
INSERT INTO `auth_item` (`name`,`type`,`description`,`rule_name`,`data`,`created_at`,`updated_at`) VALUES
('/book/*','2','','','','1571309543','1571309543');;;
INSERT INTO `auth_item` (`name`,`type`,`description`,`rule_name`,`data`,`created_at`,`updated_at`) VALUES
('/book/create','2','','','','1571309543','1571309543');;;
INSERT INTO `auth_item` (`name`,`type`,`description`,`rule_name`,`data`,`created_at`,`updated_at`) VALUES
('/book/delete','2','','','','1571309543','1571309543');;;
INSERT INTO `auth_item` (`name`,`type`,`description`,`rule_name`,`data`,`created_at`,`updated_at`) VALUES
('/book/index','2','','','','1571309542','1571309542');;;
INSERT INTO `auth_item` (`name`,`type`,`description`,`rule_name`,`data`,`created_at`,`updated_at`) VALUES
('/book/update','2','','','','1571309543','1571309543');;;
INSERT INTO `auth_item` (`name`,`type`,`description`,`rule_name`,`data`,`created_at`,`updated_at`) VALUES
('/book/view','2','','','','1571309542','1571309542');;;
INSERT INTO `auth_item` (`name`,`type`,`description`,`rule_name`,`data`,`created_at`,`updated_at`) VALUES
('/category/*','2','','','','1571309543','1571309543');;;
INSERT INTO `auth_item` (`name`,`type`,`description`,`rule_name`,`data`,`created_at`,`updated_at`) VALUES
('/category/create','2','','','','1571309543','1571309543');;;
INSERT INTO `auth_item` (`name`,`type`,`description`,`rule_name`,`data`,`created_at`,`updated_at`) VALUES
('/category/delete','2','','','','1571309543','1571309543');;;
INSERT INTO `auth_item` (`name`,`type`,`description`,`rule_name`,`data`,`created_at`,`updated_at`) VALUES
('/category/index','2','','','','1571309543','1571309543');;;
INSERT INTO `auth_item` (`name`,`type`,`description`,`rule_name`,`data`,`created_at`,`updated_at`) VALUES
('/category/update','2','','','','1571309543','1571309543');;;
INSERT INTO `auth_item` (`name`,`type`,`description`,`rule_name`,`data`,`created_at`,`updated_at`) VALUES
('/category/view','2','','','','1571309543','1571309543');;;
INSERT INTO `auth_item` (`name`,`type`,`description`,`rule_name`,`data`,`created_at`,`updated_at`) VALUES
('/cclass/*','2','','','','1571309543','1571309543');;;
INSERT INTO `auth_item` (`name`,`type`,`description`,`rule_name`,`data`,`created_at`,`updated_at`) VALUES
('/cclass/create','2','','','','1571309543','1571309543');;;
INSERT INTO `auth_item` (`name`,`type`,`description`,`rule_name`,`data`,`created_at`,`updated_at`) VALUES
('/cclass/delete','2','','','','1571309543','1571309543');;;
INSERT INTO `auth_item` (`name`,`type`,`description`,`rule_name`,`data`,`created_at`,`updated_at`) VALUES
('/cclass/index','2','','','','1571309543','1571309543');;;
INSERT INTO `auth_item` (`name`,`type`,`description`,`rule_name`,`data`,`created_at`,`updated_at`) VALUES
('/cclass/update','2','','','','1571309543','1571309543');;;
INSERT INTO `auth_item` (`name`,`type`,`description`,`rule_name`,`data`,`created_at`,`updated_at`) VALUES
('/cclass/view','2','','','','1571309543','1571309543');;;
INSERT INTO `auth_item` (`name`,`type`,`description`,`rule_name`,`data`,`created_at`,`updated_at`) VALUES
('/debug/*','2','','','','1571309542','1571309542');;;
INSERT INTO `auth_item` (`name`,`type`,`description`,`rule_name`,`data`,`created_at`,`updated_at`) VALUES
('/debug/default/*','2','','','','1571309542','1571309542');;;
INSERT INTO `auth_item` (`name`,`type`,`description`,`rule_name`,`data`,`created_at`,`updated_at`) VALUES
('/debug/default/db-explain','2','','','','1571309542','1571309542');;;
INSERT INTO `auth_item` (`name`,`type`,`description`,`rule_name`,`data`,`created_at`,`updated_at`) VALUES
('/debug/default/download-mail','2','','','','1571309542','1571309542');;;
INSERT INTO `auth_item` (`name`,`type`,`description`,`rule_name`,`data`,`created_at`,`updated_at`) VALUES
('/debug/default/index','2','','','','1571309542','1571309542');;;
INSERT INTO `auth_item` (`name`,`type`,`description`,`rule_name`,`data`,`created_at`,`updated_at`) VALUES
('/debug/default/toolbar','2','','','','1571309542','1571309542');;;
INSERT INTO `auth_item` (`name`,`type`,`description`,`rule_name`,`data`,`created_at`,`updated_at`) VALUES
('/debug/default/view','2','','','','1571309542','1571309542');;;
INSERT INTO `auth_item` (`name`,`type`,`description`,`rule_name`,`data`,`created_at`,`updated_at`) VALUES
('/debug/user/*','2','','','','1571309542','1571309542');;;
INSERT INTO `auth_item` (`name`,`type`,`description`,`rule_name`,`data`,`created_at`,`updated_at`) VALUES
('/debug/user/reset-identity','2','','','','1571309542','1571309542');;;
INSERT INTO `auth_item` (`name`,`type`,`description`,`rule_name`,`data`,`created_at`,`updated_at`) VALUES
('/debug/user/set-identity','2','','','','1571309542','1571309542');;;
INSERT INTO `auth_item` (`name`,`type`,`description`,`rule_name`,`data`,`created_at`,`updated_at`) VALUES
('/designation/*','2','','','','1571309543','1571309543');;;
INSERT INTO `auth_item` (`name`,`type`,`description`,`rule_name`,`data`,`created_at`,`updated_at`) VALUES
('/designation/create','2','','','','1571309543','1571309543');;;
INSERT INTO `auth_item` (`name`,`type`,`description`,`rule_name`,`data`,`created_at`,`updated_at`) VALUES
('/designation/delete','2','','','','1571309543','1571309543');;;
INSERT INTO `auth_item` (`name`,`type`,`description`,`rule_name`,`data`,`created_at`,`updated_at`) VALUES
('/designation/index','2','','','','1571309543','1571309543');;;
INSERT INTO `auth_item` (`name`,`type`,`description`,`rule_name`,`data`,`created_at`,`updated_at`) VALUES
('/designation/update','2','','','','1571309543','1571309543');;;
INSERT INTO `auth_item` (`name`,`type`,`description`,`rule_name`,`data`,`created_at`,`updated_at`) VALUES
('/designation/view','2','','','','1571309543','1571309543');;;
INSERT INTO `auth_item` (`name`,`type`,`description`,`rule_name`,`data`,`created_at`,`updated_at`) VALUES
('/fine/*','2','','','','1571309544','1571309544');;;
INSERT INTO `auth_item` (`name`,`type`,`description`,`rule_name`,`data`,`created_at`,`updated_at`) VALUES
('/fine/create','2','','','','1571309543','1571309543');;;
INSERT INTO `auth_item` (`name`,`type`,`description`,`rule_name`,`data`,`created_at`,`updated_at`) VALUES
('/fine/delete','2','','','','1571309544','1571309544');;;
INSERT INTO `auth_item` (`name`,`type`,`description`,`rule_name`,`data`,`created_at`,`updated_at`) VALUES
('/fine/index','2','','','','1571309543','1571309543');;;
INSERT INTO `auth_item` (`name`,`type`,`description`,`rule_name`,`data`,`created_at`,`updated_at`) VALUES
('/fine/update','2','','','','1571309544','1571309544');;;
INSERT INTO `auth_item` (`name`,`type`,`description`,`rule_name`,`data`,`created_at`,`updated_at`) VALUES
('/fine/view','2','','','','1571309543','1571309543');;;
INSERT INTO `auth_item` (`name`,`type`,`description`,`rule_name`,`data`,`created_at`,`updated_at`) VALUES
('/gii/*','2','','','','1571309542','1571309542');;;
INSERT INTO `auth_item` (`name`,`type`,`description`,`rule_name`,`data`,`created_at`,`updated_at`) VALUES
('/gii/default/*','2','','','','1571309542','1571309542');;;
INSERT INTO `auth_item` (`name`,`type`,`description`,`rule_name`,`data`,`created_at`,`updated_at`) VALUES
('/gii/default/action','2','','','','1571309542','1571309542');;;
INSERT INTO `auth_item` (`name`,`type`,`description`,`rule_name`,`data`,`created_at`,`updated_at`) VALUES
('/gii/default/diff','2','','','','1571309542','1571309542');;;
INSERT INTO `auth_item` (`name`,`type`,`description`,`rule_name`,`data`,`created_at`,`updated_at`) VALUES
('/gii/default/index','2','','','','1571309542','1571309542');;;
INSERT INTO `auth_item` (`name`,`type`,`description`,`rule_name`,`data`,`created_at`,`updated_at`) VALUES
('/gii/default/preview','2','','','','1571309542','1571309542');;;
INSERT INTO `auth_item` (`name`,`type`,`description`,`rule_name`,`data`,`created_at`,`updated_at`) VALUES
('/gii/default/view','2','','','','1571309542','1571309542');;;
INSERT INTO `auth_item` (`name`,`type`,`description`,`rule_name`,`data`,`created_at`,`updated_at`) VALUES
('/gridview/*','2','','','','1571309542','1571309542');;;
INSERT INTO `auth_item` (`name`,`type`,`description`,`rule_name`,`data`,`created_at`,`updated_at`) VALUES
('/gridview/export/*','2','','','','1571309542','1571309542');;;
INSERT INTO `auth_item` (`name`,`type`,`description`,`rule_name`,`data`,`created_at`,`updated_at`) VALUES
('/gridview/export/download','2','','','','1571309542','1571309542');;;
INSERT INTO `auth_item` (`name`,`type`,`description`,`rule_name`,`data`,`created_at`,`updated_at`) VALUES
('/issue-status/*','2','','','','1571309544','1571309544');;;
INSERT INTO `auth_item` (`name`,`type`,`description`,`rule_name`,`data`,`created_at`,`updated_at`) VALUES
('/issue-status/create','2','','','','1571309544','1571309544');;;
INSERT INTO `auth_item` (`name`,`type`,`description`,`rule_name`,`data`,`created_at`,`updated_at`) VALUES
('/issue-status/delete','2','','','','1571309544','1571309544');;;
INSERT INTO `auth_item` (`name`,`type`,`description`,`rule_name`,`data`,`created_at`,`updated_at`) VALUES
('/issue-status/index','2','','','','1571309544','1571309544');;;
INSERT INTO `auth_item` (`name`,`type`,`description`,`rule_name`,`data`,`created_at`,`updated_at`) VALUES
('/issue-status/update','2','','','','1571309544','1571309544');;;
INSERT INTO `auth_item` (`name`,`type`,`description`,`rule_name`,`data`,`created_at`,`updated_at`) VALUES
('/issue-status/view','2','','','','1571309544','1571309544');;;
INSERT INTO `auth_item` (`name`,`type`,`description`,`rule_name`,`data`,`created_at`,`updated_at`) VALUES
('/issue/*','2','','','','1571309544','1571309544');;;
INSERT INTO `auth_item` (`name`,`type`,`description`,`rule_name`,`data`,`created_at`,`updated_at`) VALUES
('/issue/create','2','','','','1571309544','1571309544');;;
INSERT INTO `auth_item` (`name`,`type`,`description`,`rule_name`,`data`,`created_at`,`updated_at`) VALUES
('/issue/delete','2','','','','1571309544','1571309544');;;
INSERT INTO `auth_item` (`name`,`type`,`description`,`rule_name`,`data`,`created_at`,`updated_at`) VALUES
('/issue/index','2','','','','1571309544','1571309544');;;
INSERT INTO `auth_item` (`name`,`type`,`description`,`rule_name`,`data`,`created_at`,`updated_at`) VALUES
('/issue/showfine','2','','','','1571309544','1571309544');;;
INSERT INTO `auth_item` (`name`,`type`,`description`,`rule_name`,`data`,`created_at`,`updated_at`) VALUES
('/issue/showfine_backend','2','','','','1571309544','1571309544');;;
INSERT INTO `auth_item` (`name`,`type`,`description`,`rule_name`,`data`,`created_at`,`updated_at`) VALUES
('/issue/status','2','','','','1571309544','1571309544');;;
INSERT INTO `auth_item` (`name`,`type`,`description`,`rule_name`,`data`,`created_at`,`updated_at`) VALUES
('/issue/update','2','','','','1571309544','1571309544');;;
INSERT INTO `auth_item` (`name`,`type`,`description`,`rule_name`,`data`,`created_at`,`updated_at`) VALUES
('/issue/view','2','','','','1571309544','1571309544');;;
INSERT INTO `auth_item` (`name`,`type`,`description`,`rule_name`,`data`,`created_at`,`updated_at`) VALUES
('/member/*','2','','','','1571309544','1571309544');;;
INSERT INTO `auth_item` (`name`,`type`,`description`,`rule_name`,`data`,`created_at`,`updated_at`) VALUES
('/member/create','2','','','','1571309544','1571309544');;;
INSERT INTO `auth_item` (`name`,`type`,`description`,`rule_name`,`data`,`created_at`,`updated_at`) VALUES
('/member/delete','2','','','','1571309544','1571309544');;;
INSERT INTO `auth_item` (`name`,`type`,`description`,`rule_name`,`data`,`created_at`,`updated_at`) VALUES
('/member/index','2','','','','1571309544','1571309544');;;
INSERT INTO `auth_item` (`name`,`type`,`description`,`rule_name`,`data`,`created_at`,`updated_at`) VALUES
('/member/update','2','','','','1571309544','1571309544');;;
INSERT INTO `auth_item` (`name`,`type`,`description`,`rule_name`,`data`,`created_at`,`updated_at`) VALUES
('/member/view','2','','','','1571309544','1571309544');;;
INSERT INTO `auth_item` (`name`,`type`,`description`,`rule_name`,`data`,`created_at`,`updated_at`) VALUES
('/organisation/*','2','','','','1571309545','1571309545');;;
INSERT INTO `auth_item` (`name`,`type`,`description`,`rule_name`,`data`,`created_at`,`updated_at`) VALUES
('/organisation/create','2','','','','1571309545','1571309545');;;
INSERT INTO `auth_item` (`name`,`type`,`description`,`rule_name`,`data`,`created_at`,`updated_at`) VALUES
('/organisation/delete','2','','','','1571309545','1571309545');;;
INSERT INTO `auth_item` (`name`,`type`,`description`,`rule_name`,`data`,`created_at`,`updated_at`) VALUES
('/organisation/index','2','','','','1571309545','1571309545');;;
INSERT INTO `auth_item` (`name`,`type`,`description`,`rule_name`,`data`,`created_at`,`updated_at`) VALUES
('/organisation/update','2','','','','1571309545','1571309545');;;
INSERT INTO `auth_item` (`name`,`type`,`description`,`rule_name`,`data`,`created_at`,`updated_at`) VALUES
('/organisation/view','2','','','','1571309545','1571309545');;;
INSERT INTO `auth_item` (`name`,`type`,`description`,`rule_name`,`data`,`created_at`,`updated_at`) VALUES
('/purchase-receipt/*','2','','','','1571309545','1571309545');;;
INSERT INTO `auth_item` (`name`,`type`,`description`,`rule_name`,`data`,`created_at`,`updated_at`) VALUES
('/purchase-receipt/create','2','','','','1571309545','1571309545');;;
INSERT INTO `auth_item` (`name`,`type`,`description`,`rule_name`,`data`,`created_at`,`updated_at`) VALUES
('/purchase-receipt/delete','2','','','','1571309545','1571309545');;;
INSERT INTO `auth_item` (`name`,`type`,`description`,`rule_name`,`data`,`created_at`,`updated_at`) VALUES
('/purchase-receipt/index','2','','','','1571309545','1571309545');;;
INSERT INTO `auth_item` (`name`,`type`,`description`,`rule_name`,`data`,`created_at`,`updated_at`) VALUES
('/purchase-receipt/update','2','','','','1571309545','1571309545');;;
INSERT INTO `auth_item` (`name`,`type`,`description`,`rule_name`,`data`,`created_at`,`updated_at`) VALUES
('/purchase-receipt/view','2','','','','1571309545','1571309545');;;
INSERT INTO `auth_item` (`name`,`type`,`description`,`rule_name`,`data`,`created_at`,`updated_at`) VALUES
('/site/*','2','','','','1571309545','1571309545');;;
INSERT INTO `auth_item` (`name`,`type`,`description`,`rule_name`,`data`,`created_at`,`updated_at`) VALUES
('/site/about','2','','','','1571309545','1571309545');;;
INSERT INTO `auth_item` (`name`,`type`,`description`,`rule_name`,`data`,`created_at`,`updated_at`) VALUES
('/site/captcha','2','','','','1571309545','1571309545');;;
INSERT INTO `auth_item` (`name`,`type`,`description`,`rule_name`,`data`,`created_at`,`updated_at`) VALUES
('/site/contact','2','','','','1571309545','1571309545');;;
INSERT INTO `auth_item` (`name`,`type`,`description`,`rule_name`,`data`,`created_at`,`updated_at`) VALUES
('/site/error','2','','','','1571309545','1571309545');;;
INSERT INTO `auth_item` (`name`,`type`,`description`,`rule_name`,`data`,`created_at`,`updated_at`) VALUES
('/site/index','2','','','','1571309545','1571309545');;;
INSERT INTO `auth_item` (`name`,`type`,`description`,`rule_name`,`data`,`created_at`,`updated_at`) VALUES
('/site/login','2','','','','1571309545','1571309545');;;
INSERT INTO `auth_item` (`name`,`type`,`description`,`rule_name`,`data`,`created_at`,`updated_at`) VALUES
('/site/logout','2','','','','1571309545','1571309545');;;
INSERT INTO `auth_item` (`name`,`type`,`description`,`rule_name`,`data`,`created_at`,`updated_at`) VALUES
('/site/request-password-reset','2','','','','1571309545','1571309545');;;
INSERT INTO `auth_item` (`name`,`type`,`description`,`rule_name`,`data`,`created_at`,`updated_at`) VALUES
('/site/reset-password','2','','','','1571309545','1571309545');;;
INSERT INTO `auth_item` (`name`,`type`,`description`,`rule_name`,`data`,`created_at`,`updated_at`) VALUES
('/site/signup','2','','','','1571309545','1571309545');;;
INSERT INTO `auth_item` (`name`,`type`,`description`,`rule_name`,`data`,`created_at`,`updated_at`) VALUES
('/site/status','2','','','','1571309545','1571309545');;;
INSERT INTO `auth_item` (`name`,`type`,`description`,`rule_name`,`data`,`created_at`,`updated_at`) VALUES
('/site/test','2','','','','1571309545','1571309545');;;
INSERT INTO `auth_item` (`name`,`type`,`description`,`rule_name`,`data`,`created_at`,`updated_at`) VALUES
('/site/typelist','2','','','','1571309545','1571309545');;;
INSERT INTO `auth_item` (`name`,`type`,`description`,`rule_name`,`data`,`created_at`,`updated_at`) VALUES
('/status/*','2','','','','1571309546','1571309546');;;
INSERT INTO `auth_item` (`name`,`type`,`description`,`rule_name`,`data`,`created_at`,`updated_at`) VALUES
('/status/create','2','','','','1571309546','1571309546');;;
INSERT INTO `auth_item` (`name`,`type`,`description`,`rule_name`,`data`,`created_at`,`updated_at`) VALUES
('/status/delete','2','','','','1571309546','1571309546');;;
INSERT INTO `auth_item` (`name`,`type`,`description`,`rule_name`,`data`,`created_at`,`updated_at`) VALUES
('/status/index','2','','','','1571309545','1571309545');;;
INSERT INTO `auth_item` (`name`,`type`,`description`,`rule_name`,`data`,`created_at`,`updated_at`) VALUES
('/status/update','2','','','','1571309546','1571309546');;;
INSERT INTO `auth_item` (`name`,`type`,`description`,`rule_name`,`data`,`created_at`,`updated_at`) VALUES
('/status/view','2','','','','1571309546','1571309546');;;
INSERT INTO `auth_item` (`name`,`type`,`description`,`rule_name`,`data`,`created_at`,`updated_at`) VALUES
('/subcategory/*','2','','','','1571309546','1571309546');;;
INSERT INTO `auth_item` (`name`,`type`,`description`,`rule_name`,`data`,`created_at`,`updated_at`) VALUES
('/subcategory/create','2','','','','1571309546','1571309546');;;
INSERT INTO `auth_item` (`name`,`type`,`description`,`rule_name`,`data`,`created_at`,`updated_at`) VALUES
('/subcategory/create2','2','','','','1571309546','1571309546');;;
INSERT INTO `auth_item` (`name`,`type`,`description`,`rule_name`,`data`,`created_at`,`updated_at`) VALUES
('/subcategory/delete','2','','','','1571309546','1571309546');;;
INSERT INTO `auth_item` (`name`,`type`,`description`,`rule_name`,`data`,`created_at`,`updated_at`) VALUES
('/subcategory/index','2','','','','1571309546','1571309546');;;
INSERT INTO `auth_item` (`name`,`type`,`description`,`rule_name`,`data`,`created_at`,`updated_at`) VALUES
('/subcategory/update','2','','','','1571309546','1571309546');;;
INSERT INTO `auth_item` (`name`,`type`,`description`,`rule_name`,`data`,`created_at`,`updated_at`) VALUES
('/subcategory/view','2','','','','1571309546','1571309546');;;
INSERT INTO `auth_item` (`name`,`type`,`description`,`rule_name`,`data`,`created_at`,`updated_at`) VALUES
('/subcategory2/*','2','','','','1571309546','1571309546');;;
INSERT INTO `auth_item` (`name`,`type`,`description`,`rule_name`,`data`,`created_at`,`updated_at`) VALUES
('/subcategory2/create','2','','','','1571309546','1571309546');;;
INSERT INTO `auth_item` (`name`,`type`,`description`,`rule_name`,`data`,`created_at`,`updated_at`) VALUES
('/subcategory2/create2','2','','','','1571309546','1571309546');;;
INSERT INTO `auth_item` (`name`,`type`,`description`,`rule_name`,`data`,`created_at`,`updated_at`) VALUES
('/subcategory2/delete','2','','','','1571309546','1571309546');;;
INSERT INTO `auth_item` (`name`,`type`,`description`,`rule_name`,`data`,`created_at`,`updated_at`) VALUES
('/subcategory2/index','2','','','','1571309546','1571309546');;;
INSERT INTO `auth_item` (`name`,`type`,`description`,`rule_name`,`data`,`created_at`,`updated_at`) VALUES
('/subcategory2/update','2','','','','1571309546','1571309546');;;
INSERT INTO `auth_item` (`name`,`type`,`description`,`rule_name`,`data`,`created_at`,`updated_at`) VALUES
('/subcategory2/view','2','','','','1571309546','1571309546');;;
INSERT INTO `auth_item` (`name`,`type`,`description`,`rule_name`,`data`,`created_at`,`updated_at`) VALUES
('/user/*','2','','','','1571309547','1571309547');;;
INSERT INTO `auth_item` (`name`,`type`,`description`,`rule_name`,`data`,`created_at`,`updated_at`) VALUES
('/user/change_password','2','','','','1571309547','1571309547');;;
INSERT INTO `auth_item` (`name`,`type`,`description`,`rule_name`,`data`,`created_at`,`updated_at`) VALUES
('/user/create','2','','','','1571309546','1571309546');;;
INSERT INTO `auth_item` (`name`,`type`,`description`,`rule_name`,`data`,`created_at`,`updated_at`) VALUES
('/user/delete','2','','','','1571309547','1571309547');;;
INSERT INTO `auth_item` (`name`,`type`,`description`,`rule_name`,`data`,`created_at`,`updated_at`) VALUES
('/user/index','2','','','','1571309546','1571309546');;;
INSERT INTO `auth_item` (`name`,`type`,`description`,`rule_name`,`data`,`created_at`,`updated_at`) VALUES
('/user/reset_password','2','','','','1571309547','1571309547');;;
INSERT INTO `auth_item` (`name`,`type`,`description`,`rule_name`,`data`,`created_at`,`updated_at`) VALUES
('/user/update','2','','','','1571309547','1571309547');;;
INSERT INTO `auth_item` (`name`,`type`,`description`,`rule_name`,`data`,`created_at`,`updated_at`) VALUES
('/user/view','2','','','','1571309546','1571309546');;;
INSERT INTO `auth_item` (`name`,`type`,`description`,`rule_name`,`data`,`created_at`,`updated_at`) VALUES
('Admin','1','','','','1569648890','1569648890');;;
INSERT INTO `auth_item` (`name`,`type`,`description`,`rule_name`,`data`,`created_at`,`updated_at`) VALUES
('librarian','1','','','','1571309510','1571309510');;;
-- -------------------------------------------
-- TABLE DATA auth_item_child
-- -------------------------------------------
INSERT INTO `auth_item_child` (`parent`,`child`) VALUES
('Admin','/*');;;
INSERT INTO `auth_item_child` (`parent`,`child`) VALUES
('librarian','/book/*');;;
INSERT INTO `auth_item_child` (`parent`,`child`) VALUES
('librarian','/issue/*');;;
-- -------------------------------------------
-- TABLE DATA auth_rule
-- -------------------------------------------
-- -------------------------------------------
-- TABLE DATA book
-- -------------------------------------------
INSERT INTO `book` (`id`,`category_id`,`code1`,`code2`,`name`,`author`,`lib_ref_no`,`price`,`ori_stock`,`cur_stock`,`shelf_no`,`publish_type`,`status`,`created_date`,`created_by`) VALUES
('1','1','0001','0011',' Black Beauty ','Sidney Sheldon','00001','1000.00','5','5','1','111','Active','2019-10-19 06:14:50','1');;;
INSERT INTO `book` (`id`,`category_id`,`code1`,`code2`,`name`,`author`,`lib_ref_no`,`price`,`ori_stock`,`cur_stock`,`shelf_no`,`publish_type`,`status`,`created_date`,`created_by`) VALUES
('2','1','0002','0012','Sidney SheldonThe Other Side of Midnight','Sidney Sheldon','00002','1000.00','1000','999','24','1115','Active','2019-10-19 06:30:03','1');;;
INSERT INTO `book` (`id`,`category_id`,`code1`,`code2`,`name`,`author`,`lib_ref_no`,`price`,`ori_stock`,`cur_stock`,`shelf_no`,`publish_type`,`status`,`created_date`,`created_by`) VALUES
('3','1','0004','0014','The Other Side of Midnight','Sewell ','00003','1000.00','500','500','12','221','Active','2019-10-19 06:56:45','1');;;
INSERT INTO `book` (`id`,`category_id`,`code1`,`code2`,`name`,`author`,`lib_ref_no`,`price`,`ori_stock`,`cur_stock`,`shelf_no`,`publish_type`,`status`,`created_date`,`created_by`) VALUES
('4','1','ART/HUM/123','GEN/657775','Rich dad poor dad','Robert','RDPD','120.00','25','24','R1/R2/34','rtytryrt rt','Active','2019-11-15 10:27:47','1');;;
-- -------------------------------------------
-- TABLE DATA category
-- -------------------------------------------
INSERT INTO `category` (`id`,`name`,`status`,`created_date`,`created_by`) VALUES
('1','Arts','Active','2019-10-19 11:43:05','1');;;
-- -------------------------------------------
-- TABLE DATA class
-- -------------------------------------------
INSERT INTO `class` (`id`,`name`,`status`,`created_date`,`created_by`) VALUES
('1','class I','Active','2019-10-19 11:42:17','1');;;
INSERT INTO `class` (`id`,`name`,`status`,`created_date`,`created_by`) VALUES
('2','class II','Active','2019-10-19 14:56:15','1');;;
INSERT INTO `class` (`id`,`name`,`status`,`created_date`,`created_by`) VALUES
('3','classIII','Active','2019-10-19 14:56:26','1');;;
INSERT INTO `class` (`id`,`name`,`status`,`created_date`,`created_by`) VALUES
('4','class IV','Active','2019-10-19 14:56:33','1');;;
INSERT INTO `class` (`id`,`name`,`status`,`created_date`,`created_by`) VALUES
('5','class V','Active','2019-10-19 14:56:39','1');;;
INSERT INTO `class` (`id`,`name`,`status`,`created_date`,`created_by`) VALUES
('6','class VI','Active','2019-10-19 14:56:47','1');;;
INSERT INTO `class` (`id`,`name`,`status`,`created_date`,`created_by`) VALUES
('7','class VII','Active','2019-10-19 14:57:05','1');;;
INSERT INTO `class` (`id`,`name`,`status`,`created_date`,`created_by`) VALUES
('8','class VIII','Active','2019-10-19 14:57:33','1');;;
INSERT INTO `class` (`id`,`name`,`status`,`created_date`,`created_by`) VALUES
('9','class IX','Active','2019-10-19 14:57:46','1');;;
INSERT INTO `class` (`id`,`name`,`status`,`created_date`,`created_by`) VALUES
('10','class X','Active','2019-10-19 14:58:02','1');;;
-- -------------------------------------------
-- TABLE DATA fine
-- -------------------------------------------
INSERT INTO `fine` (`id`,`class_id`,`amount`,`min_days`,`max_days`,`status`,`created_date`,`created_by`) VALUES
('1','1','5.00','0','0','Active','2019-10-19 11:42:39','1');;;
INSERT INTO `fine` (`id`,`class_id`,`amount`,`min_days`,`max_days`,`status`,`created_date`,`created_by`) VALUES
('2','2','10.00','0','0','Active','2019-10-19 14:58:29','1');;;
INSERT INTO `fine` (`id`,`class_id`,`amount`,`min_days`,`max_days`,`status`,`created_date`,`created_by`) VALUES
('3','3','15.00','0','0','Active','2019-10-19 14:58:39','1');;;
INSERT INTO `fine` (`id`,`class_id`,`amount`,`min_days`,`max_days`,`status`,`created_date`,`created_by`) VALUES
('4','4','20.00','0','0','Active','2019-10-19 14:59:20','1');;;
INSERT INTO `fine` (`id`,`class_id`,`amount`,`min_days`,`max_days`,`status`,`created_date`,`created_by`) VALUES
('5','5','25.00','0','0','Active','2019-10-19 14:59:32','1');;;
INSERT INTO `fine` (`id`,`class_id`,`amount`,`min_days`,`max_days`,`status`,`created_date`,`created_by`) VALUES
('6','6','30.00','0','0','Active','2019-10-19 14:59:42','1');;;
INSERT INTO `fine` (`id`,`class_id`,`amount`,`min_days`,`max_days`,`status`,`created_date`,`created_by`) VALUES
('7','7','35.00','0','0','Active','2019-10-19 14:59:56','1');;;
INSERT INTO `fine` (`id`,`class_id`,`amount`,`min_days`,`max_days`,`status`,`created_date`,`created_by`) VALUES
('8','8','40.00','0','0','Active','2019-10-19 15:00:08','1');;;
INSERT INTO `fine` (`id`,`class_id`,`amount`,`min_days`,`max_days`,`status`,`created_date`,`created_by`) VALUES
('9','9','45.00','0','0','Active','2019-10-19 15:00:19','1');;;
INSERT INTO `fine` (`id`,`class_id`,`amount`,`min_days`,`max_days`,`status`,`created_date`,`created_by`) VALUES
('10','10','50.00','0','0','Active','2019-10-19 15:01:12','1');;;
-- -------------------------------------------
-- TABLE DATA issue
-- -------------------------------------------
INSERT INTO `issue` (`id`,`book_id`,`member_id`,`status_id`,`created_date`,`created_by`,`fine`,`remark`,`s_date`,`e_date`) VALUES
('1','1','1','2','2019-11-15 10:11:25','1','0.00','','2019-11-15','2019-11-22');;;
INSERT INTO `issue` (`id`,`book_id`,`member_id`,`status_id`,`created_date`,`created_by`,`fine`,`remark`,`s_date`,`e_date`) VALUES
('2','2','2','3','2019-11-15 10:11:46','1','0.00','','2019-11-15','2019-11-21');;;
INSERT INTO `issue` (`id`,`book_id`,`member_id`,`status_id`,`created_date`,`created_by`,`fine`,`remark`,`s_date`,`e_date`) VALUES
('3','4','3','1','2019-11-15 10:34:52','1','0.00','dfgdfgdf','2019-11-16','2019-11-18');;;
-- -------------------------------------------
-- TABLE DATA issue_status
-- -------------------------------------------
INSERT INTO `issue_status` (`id`,`issue_id`,`status_id`,`remark`,`created_by`,`created_date`) VALUES
('1','1','1','','1','2019-11-15');;;
INSERT INTO `issue_status` (`id`,`issue_id`,`status_id`,`remark`,`created_by`,`created_date`) VALUES
('2','2','1','','1','2019-11-15');;;
INSERT INTO `issue_status` (`id`,`issue_id`,`status_id`,`remark`,`created_by`,`created_date`) VALUES
('4','2','3','','1','2019-11-15');;;
INSERT INTO `issue_status` (`id`,`issue_id`,`status_id`,`remark`,`created_by`,`created_date`) VALUES
('5','1','2','','1','2019-11-15');;;
INSERT INTO `issue_status` (`id`,`issue_id`,`status_id`,`remark`,`created_by`,`created_date`) VALUES
('6','3','1','','1','2019-11-15');;;
-- -------------------------------------------
-- TABLE DATA member
-- -------------------------------------------
INSERT INTO `member` (`id`,`class_id`,`code`,`name`,`address`,`email`,`phone`,`status`,`created_date`,`created_by`) VALUES
('1','1','0001','HAOBIJAM JINA DEVI','Naoremthong','jinzhaobijam2011@gmail.com','1234567893','Active','2019-10-19 11:43:33','1');;;
INSERT INTO `member` (`id`,`class_id`,`code`,`name`,`address`,`email`,`phone`,`status`,`created_date`,`created_by`) VALUES
('2','2','0004','Hemjyoti Moirangthem','Naoremthong','jojo@gmail.com','1234567896','Active','2019-10-19 15:06:12','1');;;
INSERT INTO `member` (`id`,`class_id`,`code`,`name`,`address`,`email`,`phone`,`status`,`created_date`,`created_by`) VALUES
('3','10','R123','Student 1','fghfghfg ','test@test.com','1234567890','Active','2019-11-15 10:33:50','1');;;
-- -------------------------------------------
-- TABLE DATA migration
-- -------------------------------------------
INSERT INTO `migration` (`version`,`apply_time`) VALUES
('m000000_000000_base','1569582375');;;
INSERT INTO `migration` (`version`,`apply_time`) VALUES
('m130524_201442_init','1569582382');;;
INSERT INTO `migration` (`version`,`apply_time`) VALUES
('m140506_102106_rbac_init','1569647152');;;
INSERT INTO `migration` (`version`,`apply_time`) VALUES
('m170907_052038_rbac_add_index_on_auth_assignment_user_id','1569647152');;;
-- -------------------------------------------
-- TABLE DATA organisation
-- -------------------------------------------
INSERT INTO `organisation` (`id`,`name`,`address`,`pin`,`phone`,`email`,`logo`,`created_date`,`created_by`) VALUES
('1','Organisation','Imphal','795001','1234567890','a@gmail.com','','2019-10-01 00:00:00','1');;;
-- -------------------------------------------
-- TABLE DATA purchase_receipt
-- -------------------------------------------
INSERT INTO `purchase_receipt` (`id`,`book_id`,`quantity`,`total_price`,`purchase_order_no`,`supplier`,`created_by`,`created_date`) VALUES
('1','1','5','1000.00','343we','sssdd','1','2019-11-15');;;
INSERT INTO `purchase_receipt` (`id`,`book_id`,`quantity`,`total_price`,`purchase_order_no`,`supplier`,`created_by`,`created_date`) VALUES
('2','2','1000','2000.00','hjk','gjkh','1','2019-11-15');;;
INSERT INTO `purchase_receipt` (`id`,`book_id`,`quantity`,`total_price`,`purchase_order_no`,`supplier`,`created_by`,`created_date`) VALUES
('3','3','500','5666.00','hghj','','1','2019-11-15');;;
INSERT INTO `purchase_receipt` (`id`,`book_id`,`quantity`,`total_price`,`purchase_order_no`,`supplier`,`created_by`,`created_date`) VALUES
('4','4','15','2150.00','PO123','Book Depo','1','2019-11-15');;;
-- -------------------------------------------
-- TABLE DATA status
-- -------------------------------------------
INSERT INTO `status` (`id`,`name`,`status`,`created_date`,`created_by`) VALUES
('1','Issued','Active','2019-10-01','1');;;
INSERT INTO `status` (`id`,`name`,`status`,`created_date`,`created_by`) VALUES
('2','Return','Active','2019-10-02','1');;;
INSERT INTO `status` (`id`,`name`,`status`,`created_date`,`created_by`) VALUES
('3','Lost','Active','2019-10-03','1');;;
-- -------------------------------------------
-- TABLE DATA subcategory
-- -------------------------------------------
INSERT INTO `subcategory` (`id`,`name`,`category_id`,`status`,`created_date`,`created_by`) VALUES
('1','english','1','Active','2019-10-19 11:43:17','1');;;
INSERT INTO `subcategory` (`id`,`name`,`category_id`,`status`,`created_date`,`created_by`) VALUES
('2','Poetry','1','Active','2019-11-15 10:52:51','1');;;
-- -------------------------------------------
-- TABLE DATA user
-- -------------------------------------------
INSERT INTO `user` (`id`,`username`,`auth_key`,`password_hash`,`password_reset_token`,`email`,`status`,`created_at`,`updated_at`) VALUES
('1','admin_lms','heIGvKPhvsBV-Js9M0nUL9C62CATyNtq','$2y$10$cd/B7hOayRX1kq.oH8otZe.zoLrTzRZtrKBvXpmZKV6trWI3l5CsS','','admin@admin.com','10','1507965068','1540443481');;;
INSERT INTO `user` (`id`,`username`,`auth_key`,`password_hash`,`password_reset_token`,`email`,`status`,`created_at`,`updated_at`) VALUES
('2','librarian1','Z_hQ8huLbEw5_aOmBe-uDS9Nhf8OgIYG','$2y$13$kEob2KXl5eWet6IP/wfEtefkf/DjTIuQh7uVM5pimMz19vDZa/JQa','','ll@gmail.com','10','1571473875','1571473875');;;
-- -------------------------------------------
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
COMMIT;
-- -------------------------------------------
-- -------------------------------------------
-- END BACKUP
-- -------------------------------------------
